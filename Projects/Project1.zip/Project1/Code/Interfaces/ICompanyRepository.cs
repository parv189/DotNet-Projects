﻿using Project1.Models;

namespace Project1.Code.Interfaces
{
    public interface ICompanyRepository:IRepository<Company>
    {
    }
}
