﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JWT_TOKEN.Migrations
{
    /// <inheritdoc />
    public partial class identityUsersAdded2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
